
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, desc, to_date, dayofweek, hour, avg, count, lit

spark = SparkSession.builder.appName("AnalisisRedesflix").getOrCreate()

# Cargar dataset
df = spark.read.csv("dataset/movies_analytics.csv", header=True, inferSchema=True)

# 1. Top 5 más y menos vistas
df.orderBy(desc("vistas_totales")).limit(5).write.csv("resultados/peliculas/top5_mas_vistas", header=True, mode="overwrite")
df.orderBy("vistas_totales").limit(5).write.csv("resultados/peliculas/top5_menos_vistas", header=True, mode="overwrite")

# 2. Top 5 por membresía
for tipo in ["basico", "estandar", "premium"]:
    col_name = f"vistas_{tipo}"
    df.orderBy(desc(col_name)).select("id_pelicula", "titulo_pelicula", col_name)      .limit(5).write.csv(f"resultados/peliculas/top5_{tipo}", header=True, mode="overwrite")
