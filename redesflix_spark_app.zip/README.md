
# Análisis Redesflix con PySpark

Este proyecto contiene una aplicación PySpark para analizar visualizaciones de películas desde un dataset simulado de una plataforma tipo Netflix.

## 🚀 ¿Qué hace?

Realiza:
- Top 5 películas más y menos vistas
- Top 5 por tipo de membresía (`básico`, `estándar`, `premium`)

## 📁 Contenido del ZIP

```
.
├── analisis_spark.py       # Script principal de PySpark
├── Dockerfile              # Imagen base de Spark + script
├── dataset/
│   └── movies_analytics.csv
```

## 🐳 Cómo ejecutar

1. Construir el contenedor:

```bash
docker build -t redesflix-analisis .
```

2. Ejecutar:

```bash
docker run --rm redesflix-analisis
```

3. Resultados generados en `resultados/peliculas/`.

## 📂 Resultados esperados

Archivos CSV separados por análisis, ejemplo:

```
resultados/
└── peliculas/
    ├── top5_mas_vistas/
    ├── top5_menos_vistas/
    ├── top5_basico/
    ├── top5_estandar/
    └── top5_premium/
```

---
